--Creating Database
CREATE DATABASE AcekAcademy;

Use AcekAcademy;

--Create student table to store student information
Create TABLE Students (

StudentID INT PRIMARY KEY IDENTITY (1,1),
FirstName  NVARCHAR (50),
LastName  NVARCHAR (50),
Phone  NVARCHAR (10),
DateOfBirth DATE,
Gender NVARCHAR (50)

);
-- Modify the column length of the Gender column
ALTER TABLE Students
ALTER COLUMN Gender NVARCHAR(50);

-- Insert data into the Students table
INSERT INTO Students (FirstName, LastName, Phone, DateOfBirth, Gender)
VALUES 
    ('John', 'Doe', '1234567890', '2000-01-01', 'Male'),
    ('Jane', 'Smith', '9876543210', '1999-02-15', 'Female'),
    ('Michael', 'Johnson', '5555555555', '2001-05-10', 'Male'),
    ('Emily', 'Davis', '1111111111', '2002-09-20', 'Female'),
    ('David', 'Wilson', '9999999999', '1998-12-05', 'Male');


Create TABLE  Department(
DepartmentName VARCHAR(50) PRIMARY KEY,
Location NVARCHAR (50),

);
-- Insert data into the Department table with 

INSERT INTO Department (DepartmentName, Location)
VALUES ('HR', N'Johannesburg'),
 ('Marketing', N'Cape Town'),
 ('Finance', N'Durban'),
('Research and Development', N'Pretoria');

Create TABLE Teacher (
TeacherID INT PRIMARY KEY IDENTITY (1,1),
DepartmentName VARCHAR(50) FOREIGN KEY REFERENCES Department(DepartmentName),
HeadedBy NVARCHAR  (50),
FirstName NVARCHAR  (50),
LastName NVARCHAR  (50),
Phone NVARCHAR  (50)
	
);

-- Insert data into the Teacher table

-- Insert rows with Teacher data
INSERT INTO Teacher (DepartmentName, HeadedBy, FirstName, LastName, Phone)
VALUES ('HR', N'Dr. Smith', N'John', N'Doe', N'123-456-7890'),
('Marketing', N'Prof. Johnson', N'Alice', N'Williams', N'987-654-3210'),
('Finance', N'Prof. Brown', N'Robert', N'Anderson', N'555-555-5555'),
('Research and Development', N'Dr. White', N'Susan', N'Jones', N'777-888-9999');


Create TABLE Course(
CourseID INT PRIMARY KEY IDENTITY (1,1),
DepartmentName VARCHAR(50) FOREIGN KEY REFERENCES Department(DepartmentName),
TeacherID INT FOREIGN KEY REFERENCES Teacher(TeacherID),
Duration INT,
CourseName NVARCHAR (100)
);

-- Insert rows with Course data
INSERT INTO Course (DepartmentName, TeacherID, Duration, CourseName)
VALUES ('HR', 1, 12, N'Human Resource Management'),
       ('Marketing', 2, 10, N'Marketing Strategies'),
       ('Finance', 3, 15, N'Financial Analysis'),
       ('Research and Development', 4, 14, N'Research Methods');

