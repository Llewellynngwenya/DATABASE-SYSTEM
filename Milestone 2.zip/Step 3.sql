Use AcekAcademy;

SELECT * FROM Department;
SELECT * FROM Course;

CREATE VIEW vw_DepartmentDetails AS
SELECT d.DepartmentName, d.Location, t.HeadedBy, t.FirstName, t.LastName, t.Phone
FROM Department d
JOIN Teacher t ON d.DepartmentName = t.DepartmentName;
GO

CREATE VIEW vw_CourseDetails AS
SELECT c.CourseID, c.CourseName, c.Duration, c.DepartmentName, t.TeacherID, t.FirstName, t.LastName
FROM Course c
JOIN Department d ON c.DepartmentName = d.DepartmentName
JOIN Teacher t ON c.TeacherID = t.TeacherID;

GO


